export interface ContactFormData {
  phone: string;
  type: string;
  message: string;
}
